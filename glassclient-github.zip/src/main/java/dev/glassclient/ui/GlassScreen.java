package dev.glassclient.ui;

import dev.glassclient.feature.Feature;
import dev.glassclient.feature.FeatureManager;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class GlassScreen extends Screen {
	private static final int PAD = 12;
	private static final int COL_W = 168;
	private static final int GAP = 6;
	private static final int PANEL_W = PAD * 2 + COL_W * 2 + GAP;
	private static final int HEADER_H = 46;
	private static final int ROW_H = 30;

	private final long openedAt = System.currentTimeMillis();
	private boolean lastDown = true;
	private int panelX, panelY, panelH;
	private float pillX = -1f, pillY = -1f, pillA = 0f;

	public GlassScreen() {
		super(Text.literal("Glass Client"));
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	private int cellX(int i) { return panelX + PAD + (i % 2) * (COL_W + GAP); }
	private int cellY(int i) { return panelY + HEADER_H + (i / 2) * ROW_H; }

	private int cellAt(int mx, int my) {
		for (int i = 0; i < FeatureManager.ALL.size(); i++) {
			int rx = cellX(i);
			int ry = cellY(i);
			if (mx >= rx && mx <= rx + COL_W && my >= ry && my < ry + ROW_H - 2) return i;
		}
		return -1;
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		super.render(ctx, mouseX, mouseY, delta); // Vanilla-Blur als Hintergrund

		long now = System.currentTimeMillis();
		long el = now - openedAt;
		float t = Gfx.easeOut(el / 300f);
		if (t < 0.05f) return;
		float back = Gfx.easeOutBack(el / 460f);

		List<Feature> list = FeatureManager.ALL;
		TextRenderer tr = this.textRenderer;
		int rows = (list.size() + 1) / 2;
		panelH = HEADER_H + rows * ROW_H + PAD + 10;
		panelX = (this.width - PANEL_W) / 2;
		panelY = (this.height - panelH) / 2 + Math.round((1f - back) * 22f);

		orbs(ctx, now, t);
		Gfx.glass(ctx, panelX, panelY, PANEL_W, panelH, 14, t);

		// Lichtstreifen ueber dem Header
		ctx.enableScissor(panelX + 6, panelY + 1, panelX + PANEL_W - 6, panelY + HEADER_H);
		int sx = panelX - 60 + Math.round(((now % 3600L) / 3600f) * (PANEL_W + 120));
		for (int k = 0; k < 44; k++) {
			float prof = 1f - Math.abs(k - 22) / 22f;
			ctx.fill(sx + k, panelY + 1, sx + k + 1, panelY + HEADER_H, Gfx.argb(0xFFFFFF, 0.15f * prof * t));
		}
		ctx.disableScissor();

		// Titel mit Farbverlauf
		String title = "GLASS CLIENT";
		int tx = panelX + PAD + 4;
		int ty = panelY + 11;
		for (int i = 0; i < title.length(); i++) {
			String ch = title.substring(i, i + 1);
			ctx.drawText(tr, ch, tx, ty, Gfx.argb(Gfx.accent(i * 0.05f), t), true);
			tx += tr.getWidth(ch);
		}
		ctx.drawText(tr, "1.21.11 - nur Anzeige, keine Cheats", panelX + PAD + 4, ty + 12, Gfx.argb(0xFFFFFF, 0.5f * t), false);
		ctx.fill(panelX + PAD, panelY + HEADER_H - 6, panelX + PANEL_W - PAD, panelY + HEADER_H - 5, Gfx.argb(0xFFFFFF, 0.16f * t));

		// Gleitende Auswahl-Kapsel (folgt der Maus wie bei iOS)
		int hov = cellAt(mouseX, mouseY);
		float tgx = cellX(Math.max(hov, 0));
		float tgy = cellY(Math.max(hov, 0));
		if (pillY < 0f) { pillX = tgx; pillY = tgy; }
		pillX += (tgx - pillX) * 0.35f;
		pillY += (tgy - pillY) * 0.35f;
		pillA += ((hov >= 0 ? 1f : 0f) - pillA) * 0.30f;
		if (pillA > 0.02f) {
			int px = Math.round(pillX);
			int py = Math.round(pillY);
			float pa = pillA * t;
			Gfx.roundedFill(ctx, px, py, COL_W, ROW_H - 2, 9, Gfx.argb(0xFFFFFF, 0.09f * pa));
			ctx.fillGradient(px + 4, py + 1, px + COL_W - 4, py + 9, Gfx.argb(0xFFFFFF, 0.13f * pa), Gfx.argb(0xFFFFFF, 0f));
			Gfx.roundedOutline(ctx, px, py, COL_W, ROW_H - 2, 9, Gfx.argb(0xFFFFFF, 0.26f * pa));
		}

		// Eintraege (fahren nacheinander ein)
		for (int i = 0; i < list.size(); i++) {
			Feature f = list.get(i);
			float rt = Gfx.easeOut((el - 90 - i * 35L) / 280f);
			float a = t * rt;
			if (a < 0.05f) continue;
			int rx = cellX(i);
			int ry = cellY(i) + Math.round((1f - rt) * 8f);
			f.anim += ((f.isEnabled() ? 1f : 0f) - f.anim) * 0.22f;

			ctx.drawText(tr, f.name, rx + 8, ry + 5, Gfx.argb(0xFFFFFF, a), true);
			ctx.drawText(tr, f.description, rx + 8, ry + 16, Gfx.argb(0xFFFFFF, 0.55f * a), false);

			int sw = 32, sh = 16;
			int sxx = rx + COL_W - 6 - sw;
			int syy = ry + (ROW_H - 2 - sh) / 2;
			Gfx.roundedFill(ctx, sxx, syy, sw, sh, 8, Gfx.argb(0xFFFFFF, 0.16f * a));
			if (f.anim > 0.01f) {
				Gfx.roundedFill(ctx, sxx, syy, sw, sh, 8, Gfx.argb(Gfx.accent(i * 0.1f), 0.85f * f.anim * a));
			}
			Gfx.roundedOutline(ctx, sxx, syy, sw, sh, 8, Gfx.argb(0xFFFFFF, 0.35f * a));
			int kd = sh - 4;
			int kx = sxx + 2 + Math.round(f.anim * (sw - sh));
			Gfx.roundedFill(ctx, kx, syy + 3, kd, kd, kd / 2, Gfx.argb(0x000000, 0.18f * a));
			Gfx.roundedFill(ctx, kx, syy + 2, kd, kd, kd / 2, Gfx.argb(0xFFFFFF, 0.97f * a));
		}

		String hint = "RSHIFT schliesst das Menue";
		ctx.drawText(tr, hint, panelX + (PANEL_W - tr.getWidth(hint)) / 2, panelY + panelH - 14, Gfx.argb(0xFFFFFF, 0.4f * t), false);

		// Klick per GLFW (unabhaengig von den Input-Signaturen der Version)
		boolean down = GLFW.glfwGetMouseButton(this.client.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
		if (down && !lastDown && hov >= 0) {
			list.get(hov).toggle();
			FeatureManager.save();
		}
		lastDown = down;
	}

	/** Weiche, wandernde Farb-Orbs hinter dem Glas. */
	private void orbs(DrawContext ctx, long now, float t) {
		int cx = this.width / 2;
		int cy = this.height / 2;
		for (int i = 0; i < 3; i++) {
			double a = now / 2600.0 + i * 2.1;
			int ox = cx + (int) (Math.cos(a) * 150);
			int oy = cy + (int) (Math.sin(a * 0.8) * 70);
			Gfx.glow(ctx, ox, oy, 78 + i * 10, Gfx.accent(i * 0.33f), 0.034f * t);
		}
	}
}
