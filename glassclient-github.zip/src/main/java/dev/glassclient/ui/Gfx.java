package dev.glassclient.ui;

import net.minecraft.client.gui.DrawContext;

/** Zeichen-Helfer fuer den Liquid-Glass-Look (nur DrawContext.fill / fillGradient / Scissor). */
public final class Gfx {
	private Gfx() {}

	/** rgb (0xRRGGBB, Alpha-Bits werden ignoriert) + Alpha 0..1 -> ARGB */
	public static int argb(int rgb, float alpha) {
		int a = Math.max(0, Math.min(255, Math.round(alpha * 255f)));
		return (a << 24) | (rgb & 0xFFFFFF);
	}

	/** Animierte Akzentfarbe (Cyan -> Violett -> Pink), offset verschiebt die Phase. */
	public static int accent(float offset) {
		double t = (System.currentTimeMillis() % 6000L) / 6000.0;
		double s = 0.5 + 0.5 * Math.sin((t + offset) * Math.PI * 2.0);
		float hue = 0.50f + 0.34f * (float) s;
		return 0xFF000000 | (java.awt.Color.HSBtoRGB(hue, 0.55f, 1f) & 0xFFFFFF);
	}

	public static float clamp01(float t) {
		return Math.max(0f, Math.min(1f, t));
	}

	public static float easeOut(float t) {
		float k = 1f - clamp01(t);
		return 1f - k * k * k;
	}

	/** Federnd: schiesst leicht ueber 1 hinaus und setzt sich dann (wie iOS-Animationen). */
	public static float easeOutBack(float t) {
		float x = clamp01(t) - 1f;
		float c1 = 1.70158f;
		return 1f + (c1 + 1f) * x * x * x + c1 * x * x;
	}

	private static int inset(int r, int i) {
		double dy = r - i - 0.5;
		return (int) Math.round(r - Math.sqrt(Math.max(0.0, (double) r * r - dy * dy)));
	}

	public static void roundedFill(DrawContext c, int x, int y, int w, int h, int r, int color) {
		r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
		if (r == 0) {
			c.fill(x, y, x + w, y + h, color);
			return;
		}
		c.fill(x, y + r, x + w, y + h - r, color);
		for (int i = 0; i < r; i++) {
			int in = inset(r, i);
			c.fill(x + in, y + i, x + w - in, y + i + 1, color);
			c.fill(x + in, y + h - i - 1, x + w - in, y + h - i, color);
		}
	}

	public static void roundedOutline(DrawContext c, int x, int y, int w, int h, int r, int color) {
		r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
		int top = inset(r, 0);
		c.fill(x + top, y, x + w - top, y + 1, color);
		c.fill(x + top, y + h - 1, x + w - top, y + h, color);
		for (int i = 1; i < r; i++) {
			int a = inset(r, i);
			int b = Math.max(a + 1, inset(r, i - 1));
			c.fill(x + a, y + i, x + b, y + i + 1, color);
			c.fill(x + w - b, y + i, x + w - a, y + i + 1, color);
			c.fill(x + a, y + h - i - 1, x + b, y + h - i, color);
			c.fill(x + w - b, y + h - i - 1, x + w - a, y + h - i, color);
		}
		c.fill(x, y + r, x + 1, y + h - r, color);
		c.fill(x + w - 1, y + r, x + w, y + h - r, color);
	}

	/** Weicher Leucht-Kreis aus uebereinandergelegten Schichten (Aura, Orbs). */
	public static void glow(DrawContext c, int cx, int cy, int radius, int rgb, float alphaPerLayer) {
		for (int k = 10; k >= 1; k--) {
			int r = Math.max(1, radius * k / 10);
			roundedFill(c, cx - r, cy - r, r * 2, r * 2, r, argb(rgb, alphaPerLayer));
		}
	}

	/**
	 * Liquid-Glass-Panel: weicher Schatten, milchiger Koerper, farbiger Schein am unteren Rand,
	 * Glanzlicht oben, Linsen-Innenrand und ein Rand, der oben links hell und unten rechts gedimmt ist.
	 */
	public static void glass(DrawContext c, int x, int y, int w, int h, int r, float alpha) {
		for (int i = 7; i >= 1; i--) {
			roundedFill(c, x - i, y - i + 3, w + i * 2, h + i * 2, r + i, argb(0x000000, 0.03f * alpha));
		}
		roundedFill(c, x, y, w, h, r, argb(0xFFFFFF, 0.11f * alpha));

		int gi = Math.max(1, r / 2);
		int acc = accent(0.15f);
		c.fillGradient(x + gi, y + h / 2, x + w - gi, y + h - 1, argb(acc, 0f), argb(acc, 0.11f * alpha));
		c.fillGradient(x + gi, y + 1, x + w - gi, y + Math.max(2, (int) (h * 0.45f)), argb(0xFFFFFF, 0.20f * alpha), argb(0xFFFFFF, 0f));

		roundedOutline(c, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), argb(0xFFFFFF, 0.08f * alpha));
		roundedOutline(c, x, y, w, h, r, argb(0xFFFFFF, 0.18f * alpha));

		c.enableScissor(x, y, x + (int) (w * 0.55f), y + (int) (h * 0.55f));
		roundedOutline(c, x, y, w, h, r, argb(0xFFFFFF, 0.55f * alpha));
		c.disableScissor();

		c.enableScissor(x + (int) (w * 0.60f), y + (int) (h * 0.60f), x + w, y + h);
		roundedOutline(c, x, y, w, h, r, argb(0xFFFFFF, 0.30f * alpha));
		c.disableScissor();
	}
}
