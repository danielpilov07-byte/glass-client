package dev.glassclient.effects;

import dev.glassclient.feature.FeatureManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.ParticlesMode;

/** Schaltet beim Aktivieren Partikel und Entity-Distanz herunter und stellt beim Ausschalten die alten Werte wieder her. */
public final class FpsBoost {
	private static boolean applied;
	private static ParticlesMode oldParticles;
	private static double oldEntityScale;

	private FpsBoost() {}

	public static void tick(MinecraftClient mc) {
		if (mc.options == null) return;
		boolean want = FeatureManager.FPS_BOOST.isEnabled();
		if (want && !applied) {
			oldParticles = mc.options.getParticles().getValue();
			oldEntityScale = mc.options.getEntityDistanceScaling().getValue();
			mc.options.getParticles().setValue(ParticlesMode.MINIMAL);
			mc.options.getEntityDistanceScaling().setValue(0.5);
			applied = true;
		} else if (!want && applied) {
			if (oldParticles != null) mc.options.getParticles().setValue(oldParticles);
			mc.options.getEntityDistanceScaling().setValue(oldEntityScale);
			applied = false;
		}
	}
}
