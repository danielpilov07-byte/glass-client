package dev.glassclient.effects;

import dev.glassclient.feature.FeatureManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.Heightmap;

import java.util.concurrent.ThreadLocalRandom;

/** Zusaetzliche Regen-Spritzer auf dem Boden rund um den Spieler (rein optisch). */
public final class RainSplashes {
	private RainSplashes() {}

	public static void tick(MinecraftClient mc) {
		if (!FeatureManager.RAIN_SPLASHES.isEnabled()) return;
		ClientWorld world = mc.world;
		ClientPlayerEntity player = mc.player;
		if (world == null || player == null || mc.isPaused()) return;

		float rain = world.getRainGradient(1.0f);
		if (rain < 0.2f) return;

		ThreadLocalRandom rnd = ThreadLocalRandom.current();
		int count = Math.round(12 * rain);
		BlockPos.Mutable pos = new BlockPos.Mutable();
		for (int i = 0; i < count; i++) {
			double x = player.getX() + (rnd.nextDouble() - 0.5) * 28.0;
			double z = player.getZ() + (rnd.nextDouble() - 0.5) * 28.0;
			int ix = MathHelper.floor(x);
			int iz = MathHelper.floor(z);
			int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING, ix, iz);
			pos.set(ix, y, iz);
			if (!world.getBiome(pos).value().hasPrecipitation()) continue;

			mc.particleManager.addParticle(ParticleTypes.RAIN, x, y + 0.05, z, 0.0, 0.0, 0.0);
			if (rnd.nextInt(4) == 0) {
				mc.particleManager.addParticle(ParticleTypes.SPLASH, x, y + 0.08, z, 0.0, 0.02, 0.0);
			}
		}
	}
}
