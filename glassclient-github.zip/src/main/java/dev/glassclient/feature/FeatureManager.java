package dev.glassclient.feature;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class FeatureManager {
	public static final Feature FPS = new Feature("FPS", "Bilder pro Sekunde", true);
	public static final Feature CPS = new Feature("CPS", "Klicks pro Sekunde", true);
	public static final Feature COORDS = new Feature("Koordinaten", "X / Y / Z Position", true);
	public static final Feature PING = new Feature("Ping", "Latenz zum Server", true);
	public static final Feature KEYSTROKES = new Feature("Keystrokes", "WASD und Maustasten", true);
	public static final Feature HAND_AURA = new Feature("Hand Aura", "Leuchten um die Hand", true);
	public static final Feature SLOW_SWING = new Feature("Slow Swing", "Langsamer Armschwung", true);
	public static final Feature RAIN_SPLASHES = new Feature("Rain Splashes", "Mehr Regen-Spritzer", true);
	public static final Feature FPS_BOOST = new Feature("FPS Boost", "Weniger Partikel", false);

	public static final List<Feature> ALL = List.of(FPS, CPS, COORDS, PING, KEYSTROKES, HAND_AURA, SLOW_SWING, RAIN_SPLASHES, FPS_BOOST);

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Type MAP_TYPE = new TypeToken<Map<String, Boolean>>() {}.getType();

	private FeatureManager() {}

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("glassclient.json");
	}

	public static void load() {
		Path p = file();
		if (!Files.exists(p)) return;
		try (Reader r = Files.newBufferedReader(p)) {
			Map<String, Boolean> map = GSON.fromJson(r, MAP_TYPE);
			if (map == null) return;
			for (Feature f : ALL) {
				Boolean v = map.get(f.name);
				if (v != null) {
					f.setEnabled(v);
					f.anim = v ? 1f : 0f;
				}
			}
		} catch (Exception ignored) {
		}
	}

	public static void save() {
		Map<String, Boolean> map = new LinkedHashMap<>();
		for (Feature f : ALL) map.put(f.name, f.isEnabled());
		try (Writer w = Files.newBufferedWriter(file())) {
			GSON.toJson(map, w);
		} catch (IOException ignored) {
		}
	}
}
