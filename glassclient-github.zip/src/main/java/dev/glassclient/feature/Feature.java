package dev.glassclient.feature;

public class Feature {
	public final String name;
	public final String description;
	public float anim; // 0..1, Animation fuer den Schalter im Menue
	private boolean enabled;

	public Feature(String name, String description, boolean enabled) {
		this.name = name;
		this.description = description;
		this.enabled = enabled;
		this.anim = enabled ? 1f : 0f;
	}

	public boolean isEnabled() { return enabled; }
	public void setEnabled(boolean e) { this.enabled = e; }
	public void toggle() { this.enabled = !this.enabled; }
}
