package dev.glassclient.mixin;

import dev.glassclient.feature.FeatureManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
	/** Verlaengert nur die Schwung-Animation deines eigenen Arms. Angriffs-Cooldown bleibt unveraendert. */
	@Inject(method = "getHandSwingDuration", at = @At("RETURN"), cancellable = true)
	private void glassclient$slowSwing(CallbackInfoReturnable<Integer> cir) {
		if (!FeatureManager.SLOW_SWING.isEnabled()) return;
		if ((Object) this != MinecraftClient.getInstance().player) return;
		cir.setReturnValue(Math.round(cir.getReturnValue() * 2.2f));
	}
}
