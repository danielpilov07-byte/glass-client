package dev.glassclient;

import dev.glassclient.effects.FpsBoost;
import dev.glassclient.effects.RainSplashes;
import dev.glassclient.feature.FeatureManager;
import dev.glassclient.hud.HudRenderer;
import dev.glassclient.ui.GlassScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class GlassClient implements ClientModInitializer {
	public static final String ID = "glassclient";
	private boolean lastMenuKey;

	@Override
	public void onInitializeClient() {
		FeatureManager.load();
		HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, Identifier.of(ID, "hud"), HudRenderer::render);
		ClientTickEvents.END_CLIENT_TICK.register(this::tick);
	}

	// Rechte Shift-Taste oeffnet/schliesst das Menue
	private void tick(MinecraftClient mc) {
		if (mc.getWindow() == null) return;
		RainSplashes.tick(mc);
		FpsBoost.tick(mc);
		boolean down = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
		if (down && !lastMenuKey) {
			if (mc.currentScreen instanceof GlassScreen) {
				mc.setScreen(null);
			} else if (mc.currentScreen == null && mc.world != null) {
				mc.setScreen(new GlassScreen());
			}
		}
		lastMenuKey = down;
	}
}
