package dev.glassclient.hud;

import dev.glassclient.feature.FeatureManager;
import dev.glassclient.ui.Gfx;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Arm;

import java.util.Locale;

public final class HudRenderer {
	private static final float[] KEY_ANIM = new float[7];
	private static float auraFlare;

	private HudRenderer() {}

	public static void render(DrawContext ctx, RenderTickCounter tick) {
		MinecraftClient mc = MinecraftClient.getInstance();
		Clicks.update(mc);
		if (mc.player == null || mc.options.hudHidden) return;
		TextRenderer tr = mc.textRenderer;

		if (FeatureManager.HAND_AURA.isEnabled()) {
			aura(ctx, mc);
		}

		int x = 6;
		int y = 6;

		if (FeatureManager.FPS.isEnabled()) {
			y = line(ctx, tr, x, y, "FPS", String.valueOf(mc.getCurrentFps()));
		}
		if (FeatureManager.CPS.isEnabled()) {
			y = line(ctx, tr, x, y, "CPS", Clicks.left() + " | " + Clicks.right());
		}
		if (FeatureManager.PING.isEnabled()) {
			String ping = "-";
			if (mc.getNetworkHandler() != null) {
				PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
				if (e != null) ping = e.getLatency() + " ms";
			}
			y = line(ctx, tr, x, y, "PING", ping);
		}
		if (FeatureManager.COORDS.isEnabled()) {
			String pos = String.format(Locale.ROOT, "%.1f  %.1f  %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
			y = line(ctx, tr, x, y, "XYZ", pos);
		}
		if (FeatureManager.KEYSTROKES.isEnabled()) {
			keystrokes(ctx, tr, mc, x, y + 4);
		}
	}

	private static int line(DrawContext ctx, TextRenderer tr, int x, int y, String label, String value) {
		int lw = tr.getWidth(label);
		int w = lw + tr.getWidth(value) + 18;
		Gfx.glass(ctx, x, y, w, 16, 8, 1f);
		ctx.drawText(tr, label, x + 6, y + 4, Gfx.accent(0f), true);
		ctx.drawText(tr, value, x + 12 + lw, y + 4, 0xFFFFFFFF, true);
		return y + 21;
	}

	private static void keystrokes(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int x, int y) {
		int s = 20;
		int g = 2;
		key(ctx, tr, x + s + g, y, s, s, "W", 0, mc.options.forwardKey.isPressed());
		key(ctx, tr, x, y + s + g, s, s, "A", 1, mc.options.leftKey.isPressed());
		key(ctx, tr, x + s + g, y + s + g, s, s, "S", 2, mc.options.backKey.isPressed());
		key(ctx, tr, x + 2 * (s + g), y + s + g, s, s, "D", 3, mc.options.rightKey.isPressed());
		int bw = (3 * s + 2 * g - g) / 2;
		key(ctx, tr, x, y + 2 * (s + g), bw, s, "L " + Clicks.left(), 4, Clicks.leftDown);
		key(ctx, tr, x + bw + g, y + 2 * (s + g), bw, s, "R " + Clicks.right(), 5, Clicks.rightDown);
	}

	private static void key(DrawContext ctx, TextRenderer tr, int x, int y, int w, int h, String label, int idx, boolean down) {
		KEY_ANIM[idx] += ((down ? 1f : 0f) - KEY_ANIM[idx]) * 0.3f;
		Gfx.glass(ctx, x, y, w, h, 6, 1f);
		if (KEY_ANIM[idx] > 0.02f) {
			Gfx.roundedFill(ctx, x, y, w, h, 6, Gfx.argb(Gfx.accent(idx * 0.12f), 0.55f * KEY_ANIM[idx]));
		}
		int tw = tr.getWidth(label);
		ctx.drawText(tr, label, x + (w - tw) / 2, y + (h - 8) / 2, 0xFFFFFFFF, true);
	}

	/** Rein optische Hand-Aura: pulsierender Schein um die Haupthand, blitzt bei Linksklick auf. */
	private static void aura(DrawContext ctx, MinecraftClient mc) {
		if (!mc.options.getPerspective().isFirstPerson()) return;
		int sw = ctx.getScaledWindowWidth();
		int sh = ctx.getScaledWindowHeight();
		boolean left = mc.options.getMainArm().getValue() == Arm.LEFT;

		auraFlare += ((Clicks.leftDown ? 1f : 0f) - auraFlare) * 0.25f;
		double t = System.currentTimeMillis() / 1000.0;
		float pulse = 0.5f + 0.5f * (float) Math.sin(t * 2.0);

		int cx = (int) (sw * (left ? 0.20f : 0.80f));
		int cy = (int) (sh * 0.86f);
		int radius = 70 + (int) (14 * pulse) + (int) (26 * auraFlare);
		float a = 0.030f + 0.012f * pulse + 0.035f * auraFlare;

		Gfx.glow(ctx, cx, cy, radius, Gfx.accent(0.10f), a);
		Gfx.glow(ctx, cx + (left ? -14 : 14), cy - 8, radius / 2, Gfx.accent(0.45f), a * 1.2f);
	}
}
