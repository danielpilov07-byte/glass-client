package dev.glassclient.hud;

import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.Deque;

/** Zaehlt Mausklicks pro Sekunde (pro Frame per GLFW abgefragt, ohne Mixins). */
public final class Clicks {
	private static final Deque<Long> LEFT = new ArrayDeque<>();
	private static final Deque<Long> RIGHT = new ArrayDeque<>();
	private static boolean lastL, lastR;
	public static boolean leftDown, rightDown;

	private Clicks() {}

	public static void update(MinecraftClient mc) {
		if (mc.getWindow() == null) return;
		long h = mc.getWindow().getHandle();
		boolean inGame = mc.currentScreen == null;
		leftDown = inGame && GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
		rightDown = inGame && GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
		long now = System.currentTimeMillis();
		if (leftDown && !lastL) LEFT.addLast(now);
		if (rightDown && !lastR) RIGHT.addLast(now);
		lastL = leftDown;
		lastR = rightDown;
		while (!LEFT.isEmpty() && now - LEFT.peekFirst() > 1000L) LEFT.removeFirst();
		while (!RIGHT.isEmpty() && now - RIGHT.peekFirst() > 1000L) RIGHT.removeFirst();
	}

	public static int left() { return LEFT.size(); }
	public static int right() { return RIGHT.size(); }
}
