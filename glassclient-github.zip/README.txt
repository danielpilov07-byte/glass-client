Glass Client (Fabric, Minecraft 1.21.11)

JAR ohne eigenen Compiler bauen (GitHub):
1. Auf github.com ein neues Repository erstellen (privat ist ok).
2. "uploading an existing file" waehlen und ALLE Dateien und Ordner aus diesem Ordner hochziehen
   (auch den versteckten Ordner .github). Commit klicken.
3. Oben auf den Tab "Actions" -> Workflow "build" abwarten (ca. 3-5 Minuten, gruener Haken).
4. Auf den Durchlauf klicken -> unten bei "Artifacts" glassclient-jar herunterladen und entpacken.
5. Die .jar (NICHT die -sources.jar) in den mods-Ordner legen, dazu Fabric Loader + Fabric API.

Im Spiel: Rechte Shift-Taste oeffnet das Menue.

Neu: Slow Swing, Rain Splashes, FPS Boost (Menue) und Glas-Skin fuer Sonne und Mond
(Datei-Overrides in assets/minecraft/textures/environment/). Mond/Sonne-Skin entfernen:
die beiden PNG-Dateien dort loeschen und neu bauen.
